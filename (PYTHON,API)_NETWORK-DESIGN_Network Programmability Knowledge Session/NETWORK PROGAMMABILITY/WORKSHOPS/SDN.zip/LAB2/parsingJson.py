
class key:
    primaryKey = "AIzaSyCB-oEfoz9udK2o3Kd4K_sa7ROdIqxjpnY"
